import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class main {

    public static final String DB_URL = "jdbc:postgresql://localhost:5432/Catalog";
    public static final String DB_Driver = "org.postgresql.Driver";
    static final String USER = "postgres";
    static final String PASS = "13cfcf23mmott23";

    public static void main(String[] args) {

        try {
            Class.forName(DB_Driver);
        } catch (ClassNotFoundException e) {
            System.out.println("Драйвер PostgreSQL JDBC не найден. Включите его в свой путь к библиотеке ");
            e.printStackTrace();
            return;
        }

        System.out.println("Драйвер PostgreSQL JDBC успешно подключен");
        Connection connection = null;

        try {
            connection = DriverManager.getConnection(DB_URL, USER, PASS);

        } catch (SQLException e) {
            System.out.println("Не удалось установить Соединение");
            e.printStackTrace();
            return;
        }

        if (connection != null) {
            System.out.println("Теперь вы успешно подключились к базе данных");
        } else {
            System.out.println("Не удалось установить соединение с базой данных");
        }

        Scanner in = new Scanner(System.in);
        System.out.print("Введите пусть к файлу: ");
        String filepath = in.nextLine();
        //String filepath = "plants__001.xml";
        File xmlFile = new File(filepath);
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;

        try {
            builder = factory.newDocumentBuilder();
            Document document = builder.parse(xmlFile);
            document.getDocumentElement().normalize();
            Statement statement = connection.createStatement();
            System.out.println("Корневой элемент: " + document.getDocumentElement().getNodeName());
            // получаем узлы с именем CATALOG
            // теперь XML полностью загружен в память
            // в виде объекта Document
            NodeList nodeList = document.getElementsByTagName("CATALOG");

            for (int i = 0; i < nodeList.getLength(); i++) {
                Element cataloglist = (Element)nodeList.item(i);
                String uuid = cataloglist.getAttribute("uuid");
                String date = cataloglist.getAttribute("date");
                String company = cataloglist.getAttribute("company");
                System.out.println("Catalog: " + " uuid: " + uuid + " date: " + date + " company: " + company);


                String sqlTxt = String.format("insert into D_CAT_CATALOG (DELIVERY_DATE, COMPANY, UUID) values ('%s', '%s', '%s');", date, company, uuid);
                statement.executeUpdate(sqlTxt);

                NodeList plant = cataloglist.getElementsByTagName("PLANT");
                //Цикл по PLANT в CATALOG
                for(int j = 0; j < plant.getLength(); ++j) {
                    //получаем элемент PLANT
                    Element plantlist = (Element)plant.item(j);
                    String common = plantlist.getElementsByTagName("COMMON").item(0).getFirstChild().getNodeValue();
                    System.out.println("  COMMON: " + common);
                    String botanical = plantlist.getElementsByTagName("BOTANICAL").item(0).getFirstChild().getNodeValue();
                    System.out.println("  BOTANICAL: " + botanical);
                    String zone = plantlist.getElementsByTagName("ZONE").item(0).getFirstChild().getNodeValue();
                    System.out.println("  ZONE: " + zone);
                    String light = plantlist.getElementsByTagName("LIGHT").item(0).getFirstChild().getNodeValue();
                    System.out.println("  LIGHT: " + light);
                    String price = plantlist.getElementsByTagName("PRICE").item(0).getFirstChild().getNodeValue();
                    System.out.println("  PRICE: " + price);
                    String availability = plantlist.getElementsByTagName("AVAILABILITY").item(0).getFirstChild().getNodeValue();
                    System.out.println("  AVAILABILITY: " + availability);
                    System.out.println();

                    String sqlTxt1 = String.format("insert into f_cat_plants (catalog_id, common, botanical, zone, light, price, availability) values ('%s', '%s', '%s', '%s', '%s', '%s', '%s');", uuid, common, botanical, zone, light, price, availability);
                    statement.executeUpdate(sqlTxt1);
                }
            }
        } catch (Exception exc) {
            exc.printStackTrace();
        }
    }
}
